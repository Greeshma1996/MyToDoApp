function displayRemarksDialogForNormalUsers(postId){
	document.getElementById("myToDoApp_remarks_dialog_outer_div_id").style.display = "block";
	document.getElementById('myToDoApp_remarks_dialog_textarea_id').disabled = true;
	document.getElementById('myToDoApp_remarks_dialog_textarea_id').style.height = '78%';
	document.getElementById('myToDoApp_remarks_submit_btn_id').style.visibility = 'hidden';
	document.getElementById('myToDoApp_remarks_input_id').value = postId;
	
	var request = new XMLHttpRequest();
    request.open("GET", "http://localhost:8080/MyToDoApp/remarks?postId="+postId);

    request.onreadystatechange = function() {
	
        if(this.readyState === 4 && this.status === 200) {
            document.getElementById('myToDoApp_remarks_dialog_textarea_id').value = this.responseText;
        }
    };
    request.send();
}
function displayRemarksDialogForAdmin(toDoId){
	document.getElementById('myToDoApp_remarks_dialog_outer_div_id').style.display="block";
	document.getElementById('myToDoApp_remarks_input_id').value = toDoId;
	
	var request = new XMLHttpRequest();
    request.open("GET", "http://localhost:8080/MyToDoApp/remarks?toDoId="+toDoId);

    request.onreadystatechange = function() {
	
        if(this.readyState === 4 && this.status === 200) {
            document.getElementById('myToDoApp_remarks_dialog_textarea_id').value = this.responseText;
        }
    };
    request.send();
}
function closeRemarksDialog(){
	document.getElementById("myToDoApp_remarks_dialog_outer_div_id").style.display="none";
}

function deleteToDo(toDoId){
	
	var request = new XMLHttpRequest();
    request.open("GET", "http://localhost:8080/MyToDoApp/delete?toDoId="+toDoId);

    request.onreadystatechange = function() {
	
        if(this.readyState === 4 && this.status === 200) {
            document.getElementById('myToDoApp_remarks_dialog_textarea_id').value = this.responseText;
        }
    };
    request.send();
}
