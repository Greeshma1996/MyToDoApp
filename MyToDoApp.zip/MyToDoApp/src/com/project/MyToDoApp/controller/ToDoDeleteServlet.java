package com.project.MyToDoApp.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.project.MyToDoApp.dao.ToDoDao;
import com.project.MyToDoApp.model.ToDo;

/**
 * Servlet implementation class AdminRemarksServlet
 */
@WebServlet("/delete")
public class ToDoDeleteServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public ToDoDeleteServlet() {
		super();
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
		 protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException { 
			 String toDoId = request.getParameter("toDoId");
				HttpSession session = request.getSession(true);
				String postedUser = (String) session.getAttribute("username");
				String destPage = null;
				String noPostMessage = "No To Do List Present";
				
				ToDoDao toDoDao = new ToDoDao();
				toDoDao.deleteToDo(toDoId);
				
				ArrayList<ToDo> userPostList = toDoDao.displayUserPosts(postedUser);
		        ArrayList<ToDo> allUserPostList = toDoDao.displayAllUserPosts(postedUser);
		        
		        if (userPostList != null && !(postedUser.equals("admin"))) {
				    request.setAttribute("userPostList", userPostList);
				    destPage = "home.jsp";
				}
		        else if(userPostList == null && !(postedUser.equals("admin"))) {
				    request.setAttribute("noPostMessage", noPostMessage);
				    destPage = "home.jsp";
		        }
				else if(allUserPostList != null && postedUser.equals("admin")){
				    request.setAttribute("allUserPostList", allUserPostList);
				    destPage = "home.jsp";
				}
				else if(allUserPostList == null && postedUser.equals("admin")){
				    request.setAttribute("noPostMessage", noPostMessage);
				    destPage = "home.jsp";
				}else {
					destPage = "login.jsp";
				}
		        RequestDispatcher dispatcher = request.getRequestDispatcher(destPage);
				dispatcher.forward(request, response);
		 }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String toDoId = request.getParameter("toDoId");
		HttpSession session = request.getSession(true);
		String postedUser = (String) session.getAttribute("username");
		String destPage = null;
		String noPostMessage = "No Posts";
		
		ToDoDao toDoDao = new ToDoDao();
		toDoDao.deleteToDo(toDoId);
		
		ArrayList<ToDo> userPostList = toDoDao.displayUserPosts(postedUser);
        ArrayList<ToDo> allUserPostList = toDoDao.displayAllUserPosts(postedUser);
        
        if (userPostList != null && !(postedUser.equals("admin"))) {
		    request.setAttribute("userPostList", userPostList);
		    destPage = "home.jsp";
		}
        else if(userPostList == null && !(postedUser.equals("admin"))) {
		    request.setAttribute("noPostMessage", noPostMessage);
		    destPage = "home.jsp";
        }
		else if(allUserPostList != null && postedUser.equals("admin")){
		    request.setAttribute("allUserPostList", allUserPostList);
		    destPage = "home.jsp";
		}
		else if(allUserPostList == null && postedUser.equals("admin")){
		    request.setAttribute("noPostMessage", noPostMessage);
		    destPage = "home.jsp";
		}else {
			destPage = "login.jsp";
		}
        RequestDispatcher dispatcher = request.getRequestDispatcher(destPage);
		dispatcher.forward(request, response);
	}
}