package com.project.MyToDoApp.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.project.MyToDoApp.dao.ToDoDao;
import com.project.MyToDoApp.model.ToDo;

/**
 * Servlet implementation class AdminRemarksServlet
 */
@WebServlet("/remarks")
public class AdminRemarksServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public AdminRemarksServlet() {
		super();
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
		 protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException { 
			 String postId = request.getParameter("toDoId");
			 
			 ToDoDao toDoDao = new ToDoDao();
			 ToDo remarksContent = toDoDao.getRemarks(postId);
				
				if(remarksContent.getToDoRemarks()!=null) {
					response.getWriter().write(remarksContent.getToDoRemarks());
				}
				else {
					response.getWriter().write("");
				}
		 }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String postId = request.getParameter("suggestion_hub_remarks_input_name");
		String remarksContent = request.getParameter("suggestion_hub_remarks_dialog_textarea_name");
		HttpSession session = request.getSession(true);
		String postedUser = (String) session.getAttribute("username");
		String destPage = null;
		
		ToDoDao toDoDao = new ToDoDao();
		toDoDao.updateRemarks(postId, remarksContent);
		
		ArrayList<ToDo> userPostList = toDoDao.displayUserPosts(postedUser);
        ArrayList<ToDo> allUserPostList = toDoDao.displayAllUserPosts(postedUser);
        
        if (!(postedUser.equals("admin"))) {
		    request.setAttribute("userPostList", userPostList);
		    destPage = "home.jsp";
		}
		else{
		    request.setAttribute("allUserPostList", allUserPostList);
		    destPage = "home.jsp";
		}
        RequestDispatcher dispatcher = request.getRequestDispatcher(destPage);
		dispatcher.forward(request, response);
	}
}