package com.project.MyToDoApp.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.project.MyToDoApp.dao.ToDoDao;
import com.project.MyToDoApp.dao.UserDao;
import com.project.MyToDoApp.model.ToDo;
import com.project.MyToDoApp.model.User;

/**
 * Servlet implementation class UserPostServlet
 */
@WebServlet("/postProcess")
public class UserToDoServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UserToDoServlet() {
        super();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	/*
	 * protected void doGet(HttpServletRequest request, HttpServletResponse
	 * response) throws ServletException, IOException { // TODO Auto-generated
	 * method stub
	 * response.getWriter().append("Served at: ").append(request.getContextPath());
	 * }
	 */

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String postContent = request.getParameter("myToDoApp_post_textarea_name");
		HttpSession session = request.getSession(true);
		String postedUser = (String) session.getAttribute("username");
		String destPage = null;
		String noPostMessage = "No To Do List Present";
		
		UserDao userDao = new UserDao();
		User user = userDao.findUserDetails(postedUser);
		
		ToDo toDo = new ToDo(); 
		toDo.setToDoUsername(user.getUsername());
		toDo.setToDoFirstName(user.getFirstname());
		toDo.setToDoLastName(user.getLastname());
		toDo.setToDoContent(postContent);
		
		ToDoDao toDoDao = new ToDoDao();
		toDoDao.insertPostDetails(toDo);
		
		ArrayList<ToDo> userPostList = toDoDao.displayUserPosts(postedUser);
        ArrayList<ToDo> allUserPostList = toDoDao.displayAllUserPosts(postedUser);
        
        if (userPostList != null && !(postedUser.equals("admin"))) {
		    request.setAttribute("userPostList", userPostList);
		    destPage = "home.jsp";
		}
        else if(userPostList == null && !(postedUser.equals("admin"))) {
		    request.setAttribute("noPostMessage", noPostMessage);
		    destPage = "home.jsp";
        }
		else if(allUserPostList != null && postedUser.equals("admin")){
		    request.setAttribute("allUserPostList", allUserPostList);
		    destPage = "home.jsp";
		}
		else if(allUserPostList == null && postedUser.equals("admin")){
		    request.setAttribute("noPostMessage", noPostMessage);
		    destPage = "home.jsp";
		}else {
			destPage = "login.jsp";
		}
        RequestDispatcher dispatcher = request.getRequestDispatcher(destPage);
		dispatcher.forward(request, response);
	}
}