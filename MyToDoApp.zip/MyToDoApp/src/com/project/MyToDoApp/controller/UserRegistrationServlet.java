package com.project.MyToDoApp.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.project.MyToDoApp.dao.UserDao;
import com.project.MyToDoApp.model.User;

/**
 * Servlet implementation class UserRegistrationServlet
 */
@WebServlet("/register")
public class UserRegistrationServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
		String destPage = "register.jsp";
		
		RequestDispatcher dispatcher = request.getRequestDispatcher(destPage);
	    dispatcher.forward(request, response);
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String username = request.getParameter("myToDoApp_registration_username_input_name");
		String password = request.getParameter("myToDoApp_registration_password_input_name");
		String firstname = request.getParameter("myToDoApp_registration_firstname_input_name");
		String lastname = request.getParameter("myToDoApp_registration_lastname_input_name");
		String email = request.getParameter("myToDoApp_registration_email_input_name");
		String address = request.getParameter("myToDoApp_registration_address_input_name");
		String phone = request.getParameter("myToDoApp_registration_phone_input_name");
		
		UserDao userDao = new UserDao();
		User checkUser = userDao.checkUsernameAlreadyExist(username);
		User checkPassword = userDao.checkPasswordAlreadyExist(password);
		
		if(checkUser == null && checkPassword == null) {
			User user = new User();
			user.setUsername(username);
			user.setPassword(password);;
			user.setFirstname(firstname);
			user.setLastname(lastname);
			user.setEmail(email);
			user.setAddress(address);
			user.setPhone(phone);

			try {
				  String signUpSuccessfulMessage = "User registered uccessfully";
			      userDao.registerUser(user);
				  request.setAttribute("signUpSuccessfulMessage", signUpSuccessfulMessage);
			} catch (Exception e) {
			      e.printStackTrace();
			}
		}else {
			String usernamePasswordExistMessage = "Username/Password already exist";
			request.setAttribute("usernamePasswordExistMessage", usernamePasswordExistMessage);
		}
		RequestDispatcher dispatcher = request.getRequestDispatcher("register.jsp");
		dispatcher.forward(request, response);
	}
}