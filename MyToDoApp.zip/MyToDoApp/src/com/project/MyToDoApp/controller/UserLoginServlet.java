package com.project.MyToDoApp.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.project.MyToDoApp.dao.ToDoDao;
import com.project.MyToDoApp.dao.UserDao;
import com.project.MyToDoApp.model.ToDo;
import com.project.MyToDoApp.model.User;

@WebServlet("/login")
public class UserLoginServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
 
    public UserLoginServlet() {
        super();
    }
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
		String destPage = null;
		HttpSession session = request.getSession();

		if(session.getAttribute("user")!=null) {
			String username = (String) session.getAttribute("username");
	        ToDoDao toDoDao = new ToDoDao();
	        
	        ArrayList<ToDo> userPostList = toDoDao.displayUserPosts(username);
	        ArrayList<ToDo> allUserPostList = toDoDao.displayAllUserPosts(username);
	        
	        if (!(username.equals("admin"))) {
	        	 if(!userPostList.isEmpty()) {
	 		    	request.setAttribute("userPostList", userPostList);
	 		    }
	 		    else {
	 		    	String noPostMessage = "No To Do List Present";
	 		    	request.setAttribute("noPostMessage", noPostMessage);
	 		    }
			    destPage = "home.jsp";
			}
			else {
				if(!allUserPostList.isEmpty()) {
			    	request.setAttribute("allUserPostList", allUserPostList);
			    }else{
			    	String noPostMessage = "No To Do List Present";
			    	request.setAttribute("noPostMessage", noPostMessage);
			    }
			    destPage = "home.jsp";
			}
		}
		else {
			destPage = "login.jsp";
		}
		RequestDispatcher dispatcher = request.getRequestDispatcher(destPage);
	    dispatcher.forward(request, response);
	}
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String username = request.getParameter("myToDoApp_username_input");
        String password = request.getParameter("myToDoApp_password_input");
         
        UserDao userDao = new UserDao();
        ToDoDao toDoDao = new ToDoDao();
         
        User user = userDao.checkUser(username, password);
        ArrayList<ToDo> userPostList = toDoDao.displayUserPosts(username);
        ArrayList<ToDo> allUserPostList = toDoDao.displayAllUserPosts(username);
		String destPage = "login.jsp";
		 
		if (user != null && !(username.equals("admin"))) {
		    HttpSession session = request.getSession();
		    session.setAttribute("user", user);
		    session.setAttribute("username", username);
		    if(!userPostList.isEmpty()) {
		    	request.setAttribute("userPostList", userPostList);
		    }
		    else {
		    	String noPostMessage = "No To Do List Present";
		    	request.setAttribute("noPostMessage", noPostMessage);
		    }
		    destPage = "home.jsp";
		}
		else if(user != null && username.equals("admin")){
			HttpSession session = request.getSession();
		    session.setAttribute("user", user);
		    session.setAttribute("username", username);
		    if(!allUserPostList.isEmpty()) {
		    	request.setAttribute("allUserPostList", allUserPostList);
		    }else{
		    	String noPostMessage = "No To Do List Present";
		    	request.setAttribute("noPostMessage", noPostMessage);
		    }
		    destPage = "home.jsp";
		}else {
		    String message = "Invalid username or password.";
		    request.setAttribute("message", message);
		}
		RequestDispatcher dispatcher = request.getRequestDispatcher(destPage);
		dispatcher.forward(request, response);
    }
}