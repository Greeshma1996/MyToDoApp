package com.project.MyToDoApp.model;

public class ToDo {
	private String toDoId;
	private String toDoUsername;
	private String toDoFirstName;
	private String toDoLastName;
	private String toDoContent;
	private String toDoRemarks;
	private String toDoDate;
	
	public String getToDoId() {
		return toDoId;
	}
	public void setToDoId(String toDoId) {
		this.toDoId = toDoId;
	}
	public String getToDoUsername() {
		return toDoUsername;
	}
	public void setToDoUsername(String toDoUsername) {
		this.toDoUsername = toDoUsername;
	}
	public String getToDoFirstName() {
		return toDoFirstName;
	}
	public void setToDoFirstName(String toDoFirstName) {
		this.toDoFirstName = toDoFirstName;
	}
	public String getToDoLastName() {
		return toDoLastName;
	}
	public void setToDoLastName(String toDoLastName) {
		this.toDoLastName = toDoLastName;
	}
	public String getToDoContent() {
		return toDoContent;
	}
	public void setToDoContent(String toDoContent) {
		this.toDoContent = toDoContent;
	}
	public String getToDoRemarks() {
		return toDoRemarks;
	}
	public void setToDoRemarks(String toDoRemarks) {
		this.toDoRemarks = toDoRemarks;
	}
	public String getToDoDate() {
		return toDoDate;
	}
	public void setToDoDate(String toDoDate) {
		this.toDoDate = toDoDate;
	}
}