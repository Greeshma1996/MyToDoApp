package com.project.MyToDoApp.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;

import com.project.MyToDoApp.model.ToDo;
import com.project.MyToDoApp.util.DBConnection;

public class ToDoDao {

	public String insertPostDetails(ToDo toDo) {
		Connection con = null;
        PreparedStatement preparedStatement = null;         
        try
        {
            con = DBConnection.createConnection();
            DateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
            Calendar cal = Calendar.getInstance();
            String toDoDate = dateFormat.format(cal.getTime());
            
            String query = "insert into todo(todo_username, todo_firstname, todo_lastname, todo_content, todo_date) values (?, ?, ?, ?, ?);";
            preparedStatement = con.prepareStatement(query);
            preparedStatement.setString(1, toDo.getToDoUsername());
            preparedStatement.setString(2, toDo.getToDoFirstName());
            preparedStatement.setString(3, toDo.getToDoLastName());
            preparedStatement.setString(4, toDo.getToDoContent());
            preparedStatement.setString(5, toDoDate);
            
            int result= preparedStatement.executeUpdate();
            
            if (result!=0)
            	return "SUCCESS"; 
        }
        catch(SQLException e)
        {
           e.printStackTrace();
        }       
        return "Oops.. Something went wrong there..!";
		
	}
	
	public String deleteToDo(String toDoId) {
		Connection con = null;
        PreparedStatement preparedStatement = null;         
        try
        {
            con = DBConnection.createConnection();
            
            String query = "delete FROM todo WHERE todo_id = ?";
            preparedStatement = con.prepareStatement(query);
            preparedStatement.setString(1, toDoId);
            
            int result= preparedStatement.executeUpdate();
            
            if (result!=0)
            	return "SUCCESS"; 
        }
        catch(SQLException e)
        {
           e.printStackTrace();
        }       
        return "Oops.. Something went wrong there..!";
		
	}

	public ArrayList<ToDo> displayUserPosts(String username) {
		Connection con = null;
        PreparedStatement preparedStatement = null;
        ToDo toDo = null;
        ArrayList<ToDo> userPostList = new ArrayList<ToDo>();
        try
        {
            con = DBConnection.createConnection();
            String query = "SELECT todo_id, todo_content, todo_date FROM todo WHERE todo_username = ?";
            preparedStatement = con.prepareStatement(query);
            preparedStatement.setString(1, username);
            
            ResultSet result= preparedStatement.executeQuery();
            
    		while (result.next()) {
    			toDo = new ToDo();
    			toDo.setToDoId(result.getString("todo_id"));
    			toDo.setToDoContent(result.getString("todo_content"));
    			toDo.setToDoDate(result.getString("todo_date"));
    			userPostList.add(toDo);
    		}
    		con.close();
        }
        catch(SQLException e)
        {
           e.printStackTrace();
        }       
        return userPostList;
	}
	public ArrayList<ToDo> displayAllUserPosts(String username) {
		Connection con = null;
        PreparedStatement preparedStatement = null;
        ToDo toDo = null;
        ArrayList<ToDo> allUserPostList = new ArrayList<ToDo>();
        try
        {
            con = DBConnection.createConnection();
            String query = "SELECT * FROM todo";
            preparedStatement = con.prepareStatement(query);
            
            ResultSet result= preparedStatement.executeQuery();
            
    		while (result.next()) {
    			toDo = new ToDo();
    			toDo.setToDoId(result.getString("todo_id"));
    			toDo.setToDoUsername(result.getString("todo_username"));
    			toDo.setToDoFirstName(result.getString("todo_firstname"));
    			toDo.setToDoLastName(result.getString("todo_lastname"));
    			toDo.setToDoContent(result.getString("todo_content"));
    			toDo.setToDoDate(result.getString("todo_date"));
    			allUserPostList.add(toDo);
    		}
    		con.close();
        }
        catch(SQLException e)
        {
           e.printStackTrace();
        }       
        return allUserPostList;
	}

	public String updateRemarks(String postId, String remarksContent) {
		Connection con = null;
        PreparedStatement preparedStatement = null;         
        try
        {
            con = DBConnection.createConnection();
            String query = "UPDATE todo SET todo_remarks = ? WHERE todo_id = ?;";
            preparedStatement = con.prepareStatement(query);
            preparedStatement.setString(1, remarksContent);
            preparedStatement.setString(2, postId);
            
            int result= preparedStatement.executeUpdate();
            
            if (result!=0)
            	return "SUCCESS"; 
        }
        catch(SQLException e)
        {
           e.printStackTrace();
        }       
        return "Oops.. Something went wrong there..!";
		
	}

	public ToDo getRemarks(String postId) {
		Connection con = null;
        PreparedStatement preparedStatement = null;
        ToDo toDo = null;
        try
        {
            con = DBConnection.createConnection();
            String query = "SELECT todo_remarks FROM todo WHERE todo_id = ?";
            preparedStatement = con.prepareStatement(query);
            preparedStatement.setString(1, postId);
            
            ResultSet result= preparedStatement.executeQuery();
            
    		if (result.next()) {
    			toDo = new ToDo();
    			toDo.setToDoRemarks(result.getString("todo_remarks"));
    		}
    		con.close();
        }
        catch(SQLException e)
        {
           e.printStackTrace();
        }
        return toDo;
	}
}