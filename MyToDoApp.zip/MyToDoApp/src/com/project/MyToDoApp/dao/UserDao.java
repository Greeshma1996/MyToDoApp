package com.project.MyToDoApp.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.project.MyToDoApp.model.User;
import com.project.MyToDoApp.util.DBConnection;

public class UserDao {
	
	public User checkUser(String username, String password) {
		
        Connection con = null;
        PreparedStatement preparedStatement = null;
        User user = null;
        try
        {
            con = DBConnection.createConnection();
            String query = "SELECT * FROM Users WHERE username = ? and password = ?";
            preparedStatement = con.prepareStatement(query);
            preparedStatement.setString(1, username);
            preparedStatement.setString(2, password);
            
            ResultSet result= preparedStatement.executeQuery();
            
    		if (result.next()) {
    			user = new User();
    			user.setUsername(result.getString("username"));
    			//user.setEmail(email);
    		}
    		con.close();
        }
        catch(SQLException e)
        {
           e.printStackTrace();
        }       
        return user; 
	}
	public String registerUser(User user) {
		
        Connection con = null;
        PreparedStatement preparedStatement = null;         
        try
        {
            con = DBConnection.createConnection();
            String query = "insert into Users(username, password, firstname, lastname, email, address, phone) values (?, ?, ?, ?, ?, ?, ?);";
            preparedStatement = con.prepareStatement(query);
            preparedStatement.setString(1, user.getUsername());
            preparedStatement.setString(2, user.getPassword());
            preparedStatement.setString(3, user.getFirstname());
            preparedStatement.setString(4, user.getLastname());
            preparedStatement.setString(5, user.getEmail());
            preparedStatement.setString(6, user.getAddress());
            preparedStatement.setString(7, user.getPhone());
            
            int result= preparedStatement.executeUpdate();
            
            if (result!=0)
            return "SUCCESS"; 
        }
        catch(SQLException e)
        {
           e.printStackTrace();
        }       
        return "Oops.. Something went wrong there..!";
	}
	
public User findUserDetails(String postedUser) {
		
        Connection con = null;
        PreparedStatement preparedStatement = null;
        User user = null;
        try
        {
            con = DBConnection.createConnection();
            String query = "SELECT username, firstname, lastname FROM Users WHERE username = ?";
            preparedStatement = con.prepareStatement(query);
            preparedStatement.setString(1, postedUser);
            
            ResultSet result= preparedStatement.executeQuery();
            
    		if (result.next()) {
    			user = new User();
    			user.setUsername(result.getString("username"));
    			user.setFirstname(result.getString("firstname"));
    			user.setLastname(result.getString("lastname"));
    		}
    		con.close();
        }
        catch(SQLException e)
        {
           e.printStackTrace();
        }       
        return user; 
	}
public User checkUsernameAlreadyExist(String username) {
	
	Connection con = null;
    PreparedStatement preparedStatement = null;
    User user = null;
    try
    {
        con = DBConnection.createConnection();
        String query = "SELECT * FROM Users WHERE username = ?";
        preparedStatement = con.prepareStatement(query);
        preparedStatement.setString(1, username);
        
        ResultSet result= preparedStatement.executeQuery();
        
		if (result.next()) {
			user = new User();
			user.setUsername(result.getString("username"));
		}
		con.close();
    }
    catch(SQLException e)
    {
       e.printStackTrace();
    }       
    return user;
}
public User checkPasswordAlreadyExist(String password) {
	Connection con = null;
    PreparedStatement preparedStatement = null;
    User user = null;
    try
    {
        con = DBConnection.createConnection();
        String query = "SELECT * FROM Users WHERE password = ?";
        preparedStatement = con.prepareStatement(query);
        preparedStatement.setString(1, password);
        
        ResultSet result= preparedStatement.executeQuery();
        
		if (result.next()) {
			user = new User();
			user.setPassword(result.getString("password"));
		}
		con.close();
    }
    catch(SQLException e)
    {
       e.printStackTrace();
    }       
    return user;
}
}